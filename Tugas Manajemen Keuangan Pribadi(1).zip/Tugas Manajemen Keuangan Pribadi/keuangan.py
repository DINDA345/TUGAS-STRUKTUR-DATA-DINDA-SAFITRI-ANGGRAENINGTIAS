import csv
import os
from datetime import datetime
from collections import defaultdict
from typing import Optional, List, Dict, Any

# Implementasi Linked List untuk riwayat transaksi
class TransactionNode:
    def __init__(self, transaction_data: Dict[str, Any]):
        self.data = transaction_data
        self.next = None

class LinkedList:
    def __init__(self):
        self.head = None
        self.size = 0
    
    def append(self, transaction_data: Dict[str, Any]):
        new_node = TransactionNode(transaction_data)
        if not self.head:
            self.head = new_node
        else:
            current = self.head
            while current.next:
                current = current.next
            current.next = new_node
        self.size += 1
    
    def to_list(self) -> List[Dict[str, Any]]:
        result = []
        current = self.head
        while current:
            result.append(current.data)
            current = current.next
        return result
    
    def clear(self):
        self.head = None
        self.size = 0

# Implementasi Stack untuk undo operations
class Stack:
    def __init__(self):
        self.items = []
    
    def push(self, item):
        self.items.append(item)
    
    def pop(self):
        if self.items:
            return self.items.pop()
        return None
    
    def is_empty(self):
        return len(self.items) == 0
    
    def peek(self):
        if self.items:
            return self.items[-1]
        return None

# Implementasi HashMap untuk kategori
class CategoryHashMap:
    def __init__(self):
        # Kategori pemasukan
        self.income_categories = {
            'gaji': 'Gaji Bulanan',
            'freelance': 'Freelance',
            'bonus': 'Bonus',
            'investasi': 'Hasil Investasi',
            'bisnis': 'Bisnis Sampingan',
            'hadiah': 'Hadiah',
            'lainnya': 'Lainnya'
        }
        
        # Kategori pengeluaran
        self.expense_categories = {
            'makanan': 'Makanan & Minuman',
            'transportasi': 'Transportasi',
            'belanja': 'Belanja',
            'hiburan': 'Hiburan',
            'kesehatan': 'Kesehatan',
            'pendidikan': 'Pendidikan',
            'tagihan': 'Tagihan & Utilitas',
            'investasi': 'Investasi',
            'lainnya': 'Lainnya'
        }
    
    def get_category(self, key: str, tipe: str = 'pengeluaran') -> str:
        if tipe.lower() == 'pemasukan':
            return self.income_categories.get(key.lower(), 'Lainnya')
        else:
            return self.expense_categories.get(key.lower(), 'Lainnya')
    
    def add_category(self, key: str, value: str, tipe: str = 'pengeluaran'):
        if tipe.lower() == 'pemasukan':
            self.income_categories[key.lower()] = value
        else:
            self.expense_categories[key.lower()] = value
    
    def get_categories_by_type(self, tipe: str) -> Dict[str, str]:
        if tipe.lower() == 'pemasukan':
            return self.income_categories.copy()
        else:
            return self.expense_categories.copy()
    
    def get_all_categories(self) -> Dict[str, Dict[str, str]]:
        return {
            'pemasukan': self.income_categories.copy(),
            'pengeluaran': self.expense_categories.copy()
        }

class PersonalFinanceManager:
    def __init__(self, csv_file: str = 'keuangan_pribadi.csv'):
        self.csv_file = csv_file
        self.transactions = LinkedList()
        self.undo_stack = Stack()
        self.category_map = CategoryHashMap()
        self.fieldnames = ['id', 'tanggal', 'tipe', 'jumlah', 'kategori', 'deskripsi']
        self.load_data()
    
    def load_data(self):
        """Membaca data dari file CSV"""
        if os.path.exists(self.csv_file):
            try:
                with open(self.csv_file, 'r', newline='', encoding='utf-8') as file:
                    reader = csv.DictReader(file)
                    for row in reader:
                        # Konversi tipe data
                        row['id'] = int(row['id'])
                        row['jumlah'] = float(row['jumlah'])
                        self.transactions.append(row)
            except Exception as e:
                print(f"Error loading data: {e}")
        else:
            self.create_csv_file()
    
    def create_csv_file(self):
        """Membuat file CSV baru jika tidak ada"""
        with open(self.csv_file, 'w', newline='', encoding='utf-8') as file:
            writer = csv.DictWriter(file, fieldnames=self.fieldnames)
            writer.writeheader()
    
    def save_data(self):
        """Menyimpan data ke file CSV"""
        try:
            with open(self.csv_file, 'w', newline='', encoding='utf-8') as file:
                writer = csv.DictWriter(file, fieldnames=self.fieldnames)
                writer.writeheader()
                for transaction in self.transactions.to_list():
                    writer.writerow(transaction)
        except Exception as e:
            print(f"Error saving data: {e}")
    
    def get_next_id(self) -> int:
        """Mendapatkan ID berikutnya"""
        transactions = self.transactions.to_list()
        if not transactions:
            return 1
        return max(t['id'] for t in transactions) + 1
    
    def create_transaction(self, tipe: str, jumlah: float, kategori: str, deskripsi: str):
        """CREATE - Menambah transaksi baru"""
        transaction = {
            'id': self.get_next_id(),
            'tanggal': datetime.now().strftime('%Y-%m-%d'),
            'tipe': tipe,
            'jumlah': jumlah,
            'kategori': self.category_map.get_category(kategori),
            'deskripsi': deskripsi
        }
        
        # Simpan state untuk undo
        self.undo_stack.push(('create', transaction.copy()))
        
        self.transactions.append(transaction)
        self.save_data()
        print(f"Transaksi berhasil ditambahkan dengan ID: {transaction['id']}")
    
    def read_transactions(self, filter_type: str = None) -> List[Dict[str, Any]]:
        """READ - Membaca semua transaksi atau berdasarkan filter"""
        transactions = self.transactions.to_list()
        if filter_type:
            transactions = [t for t in transactions if t['tipe'].lower() == filter_type.lower()]
        return transactions
    
    def update_transaction(self, transaction_id: int, **kwargs):
        """UPDATE - Mengupdate transaksi berdasarkan ID"""
        transactions = self.transactions.to_list()
        for i, transaction in enumerate(transactions):
            if transaction['id'] == transaction_id:
                # Simpan state untuk undo
                old_transaction = transaction.copy()
                self.undo_stack.push(('update', old_transaction))
                
                # Update fields
                for key, value in kwargs.items():
                    if key in self.fieldnames and key != 'id':
                        if key == 'kategori':
                            transaction[key] = self.category_map.get_category(value)
                        else:
                            transaction[key] = value
                
                # Rebuild linked list
                self.transactions.clear()
                for t in transactions:
                    self.transactions.append(t)
                
                self.save_data()
                print(f"Transaksi ID {transaction_id} berhasil diupdate")
                return True
        
        print(f"Transaksi dengan ID {transaction_id} tidak ditemukan")
        return False
    
    def delete_transaction(self, transaction_id: int):
        """DELETE - Menghapus transaksi berdasarkan ID"""
        transactions = self.transactions.to_list()
        for i, transaction in enumerate(transactions):
            if transaction['id'] == transaction_id:
                # Simpan state untuk undo
                self.undo_stack.push(('delete', transaction.copy()))
                
                # Remove transaction
                transactions.pop(i)
                
                # Rebuild linked list
                self.transactions.clear()
                for t in transactions:
                    self.transactions.append(t)
                
                self.save_data()
                print(f"Transaksi ID {transaction_id} berhasil dihapus")
                return True
        
        print(f"Transaksi dengan ID {transaction_id} tidak ditemukan")
        return False
    
    def undo_last_operation(self):
        """Undo operasi terakhir"""
        if self.undo_stack.is_empty():
            print("Tidak ada operasi yang bisa di-undo")
            return
        
        operation, data = self.undo_stack.pop()
        transactions = self.transactions.to_list()
        
        if operation == 'create':
            # Hapus transaksi yang baru ditambahkan
            transactions = [t for t in transactions if t['id'] != data['id']]
            print(f"Undo create: Transaksi ID {data['id']} telah dihapus")
        
        elif operation == 'delete':
            # Tambahkan kembali transaksi yang dihapus
            transactions.append(data)
            transactions.sort(key=lambda x: x['id'])
            print(f"Undo delete: Transaksi ID {data['id']} telah dikembalikan")
        
        elif operation == 'update':
            # Kembalikan data lama
            for i, t in enumerate(transactions):
                if t['id'] == data['id']:
                    transactions[i] = data
                    break
            print(f"Undo update: Transaksi ID {data['id']} telah dikembalikan")
        
        # Rebuild linked list
        self.transactions.clear()
        for t in transactions:
            self.transactions.append(t)
        
        self.save_data()
    
    def get_monthly_report(self, year: int, month: int) -> Dict[str, Any]:
        """Laporan bulanan"""
        transactions = self.transactions.to_list()
        monthly_transactions = []
        
        for t in transactions:
            t_date = datetime.strptime(t['tanggal'], '%Y-%m-%d')
            if t_date.year == year and t_date.month == month:
                monthly_transactions.append(t)
        
        # Hitung total pemasukan dan pengeluaran
        total_income = sum(t['jumlah'] for t in monthly_transactions if t['tipe'].lower() == 'pemasukan')
        total_expense = sum(t['jumlah'] for t in monthly_transactions if t['tipe'].lower() == 'pengeluaran')
        
        # Kategorisasi pemasukan dan pengeluaran
        income_by_category = defaultdict(float)
        expense_by_category = defaultdict(float)
        
        for t in monthly_transactions:
            if t['tipe'].lower() == 'pemasukan':
                income_by_category[t['kategori']] += t['jumlah']
            else:
                expense_by_category[t['kategori']] += t['jumlah']
        
        return {
            'total_income': total_income,
            'total_expense': total_expense,
            'balance': total_income - total_expense,
            'income_by_category': dict(income_by_category),
            'expense_by_category': dict(expense_by_category),
            'transaction_count': len(monthly_transactions)
        }
    
    def get_yearly_report(self, year: int) -> Dict[str, Any]:
        """Laporan tahunan"""
        transactions = self.transactions.to_list()
        yearly_transactions = []
        
        for t in transactions:
            t_date = datetime.strptime(t['tanggal'], '%Y-%m-%d')
            if t_date.year == year:
                yearly_transactions.append(t)
        
        # Hitung total pemasukan dan pengeluaran
        total_income = sum(t['jumlah'] for t in yearly_transactions if t['tipe'].lower() == 'pemasukan')
        total_expense = sum(t['jumlah'] for t in yearly_transactions if t['tipe'].lower() == 'pengeluaran')
        
        # Laporan per bulan
        monthly_summary = defaultdict(lambda: {'income': 0, 'expense': 0})
        for t in yearly_transactions:
            t_date = datetime.strptime(t['tanggal'], '%Y-%m-%d')
            month_key = f"{t_date.year}-{t_date.month:02d}"
            if t['tipe'].lower() == 'pemasukan':
                monthly_summary[month_key]['income'] += t['jumlah']
            else:
                monthly_summary[month_key]['expense'] += t['jumlah']
        
        return {
            'total_income': total_income,
            'total_expense': total_expense,
            'balance': total_income - total_expense,
            'monthly_summary': dict(monthly_summary),
            'transaction_count': len(yearly_transactions)
        }

def display_menu():
    """Menampilkan menu utama"""
    print("\n" + "="*50)
    print("    APLIKASI MANAJEMEN KEUANGAN PRIBADI")
    print("="*50)
    print("1. Tambah Transaksi")
    print("2. Lihat Semua Transaksi")
    print("3. Lihat Pemasukan")
    print("4. Lihat Pengeluaran")
    print("5. Update Transaksi")
    print("6. Hapus Transaksi")
    print("7. Undo Operasi Terakhir")
    print("8. Laporan Bulanan")
    print("9. Laporan Tahunan")
    print("10. Lihat Kategori")
    print("11. Tambah Kategori")
    print("0. Keluar")
    print("="*50)

def display_transactions(transactions: List[Dict[str, Any]]):
    """Menampilkan daftar transaksi"""
    if not transactions:
        print("Tidak ada transaksi")
        return
    
    print("\n" + "="*80)
    print(f"{'ID':<4} {'Tanggal':<12} {'Tipe':<12} {'Jumlah':<15} {'Kategori':<15} {'Deskripsi':<20}")
    print("-"*80)
    
    for t in transactions:
        print(f"{t['id']:<4} {t['tanggal']:<12} {t['tipe']:<12} {t['jumlah']:<15,.0f} {t['kategori']:<15} {t['deskripsi']:<20}")

def main():
    """Fungsi utama aplikasi"""
    fm = PersonalFinanceManager()
    
    while True:
        display_menu()
        choice = input("Pilih menu (0-11): ")
        
        if choice == '1':
            # Tambah Transaksi
            print("\nTambah Transaksi Baru")
            print("Tipe transaksi: 1=Pemasukan, 2=Pengeluaran")
            tipe_choice = input("Pilih tipe (1/2): ")
            tipe = 'pemasukan' if tipe_choice == '1' else 'pengeluaran'
            
            try:
                jumlah = float(input("Jumlah: "))
                if jumlah <= 0:
                    print("Jumlah harus lebih dari 0")
                    continue
                
                print(f"\nKategori {tipe.title()} yang tersedia:")
                categories = fm.category_map.get_categories_by_type(tipe)
                for key, value in categories.items():
                    print(f"  {key}: {value}")
                
                kategori = input("Kategori: ")
                deskripsi = input("Deskripsi: ")
                
                fm.create_transaction(tipe, jumlah, kategori, deskripsi)
                
            except ValueError:
                print("Input jumlah tidak valid")
        
        elif choice == '2':
            # Lihat Semua Transaksi
            print("\nSemua Transaksi")
            transactions = fm.read_transactions()
            display_transactions(transactions)
        
        elif choice == '3':
            # Lihat Pemasukan
            print("\nDaftar Pemasukan")
            transactions = fm.read_transactions('pemasukan')
            display_transactions(transactions)
        
        elif choice == '4':
            # Lihat Pengeluaran
            print("\nDaftar Pengeluaran")
            transactions = fm.read_transactions('pengeluaran')
            display_transactions(transactions)
        
        elif choice == '5':
            # Update Transaksi
            try:
                transaction_id = int(input("Masukkan ID transaksi yang akan diupdate: "))
                
                print("Kosongkan field yang tidak ingin diubah (tekan Enter)")
                jumlah_str = input("Jumlah baru: ")
                kategori = input("Kategori baru: ")
                deskripsi = input("Deskripsi baru: ")
                
                update_data = {}
                if jumlah_str:
                    update_data['jumlah'] = float(jumlah_str)
                if kategori:
                    update_data['kategori'] = kategori
                if deskripsi:
                    update_data['deskripsi'] = deskripsi
                
                if update_data:
                    fm.update_transaction(transaction_id, **update_data)
                else:
                    print("Tidak ada perubahan yang dilakukan")
                    
            except ValueError:
                print("Input tidak valid")
        
        elif choice == '6':
            # Hapus Transaksi
            try:
                transaction_id = int(input("Masukkan ID transaksi yang akan dihapus: "))
                confirm = input(f"Yakin ingin menghapus transaksi ID {transaction_id}? (y/n): ")
                if confirm.lower() == 'y':
                    fm.delete_transaction(transaction_id)
            except ValueError:
                print("Input ID tidak valid")
        
        elif choice == '7':
            # Undo Operasi Terakhir
            fm.undo_last_operation()
        
        elif choice == '8':
            # Laporan Bulanan
            try:
                year = int(input("Tahun: "))
                month = int(input("Bulan (1-12): "))
                
                if month < 1 or month > 12:
                    print("Bulan harus antara 1-12")
                    continue
                
                report = fm.get_monthly_report(year, month)
                
                print(f"\nLaporan Bulan {month}/{year}")
                print("="*40)
                print(f"Total Pemasukan: Rp {report['total_income']:,.0f}")
                print(f"Total Pengeluaran: Rp {report['total_expense']:,.0f}")
                print(f"Saldo: Rp {report['balance']:,.0f}")
                print(f"Jumlah Transaksi: {report['transaction_count']}")
                
                if report['income_by_category']:
                    print("\nPemasukan per Kategori:")
                    for kategori, jumlah in report['income_by_category'].items():
                        print(f"  {kategori}: Rp {jumlah:,.0f}")
                
                if report['expense_by_category']:
                    print("\nPengeluaran per Kategori:")
                    for kategori, jumlah in report['expense_by_category'].items():
                        print(f"  {kategori}: Rp {jumlah:,.0f}")
                
            except ValueError:
                print("Input tahun/bulan tidak valid")
        
        elif choice == '9':
            # Laporan Tahunan
            try:
                year = int(input("Tahun: "))
                
                report = fm.get_yearly_report(year)
                
                print(f"\nLaporan Tahun {year}")
                print("="*40)
                print(f"Total Pemasukan: Rp {report['total_income']:,.0f}")
                print(f"Total Pengeluaran: Rp {report['total_expense']:,.0f}")
                print(f"Saldo: Rp {report['balance']:,.0f}")
                print(f"Jumlah Transaksi: {report['transaction_count']}")
                
                if report['monthly_summary']:
                    print("\nRingkasan Bulanan:")
                    for month, data in sorted(report['monthly_summary'].items()):
                        balance = data['income'] - data['expense']
                        print(f"  {month}: Pemasukan Rp {data['income']:,.0f}, Pengeluaran Rp {data['expense']:,.0f}, Saldo Rp {balance:,.0f}")
                
            except ValueError:
                print("Input tahun tidak valid")
        
        elif choice == '10':
            # Lihat Kategori
            print("\nDaftar Kategori:")
            all_categories = fm.category_map.get_all_categories()
            
            print("\nKategori Pemasukan:")
            for key, value in all_categories['pemasukan'].items():
                print(f"  {key}: {value}")
            
            print("\nKategori Pengeluaran:")
            for key, value in all_categories['pengeluaran'].items():
                print(f"  {key}: {value}")
        
        elif choice == '11':
            # Tambah Kategori
            print("Tambah kategori untuk: 1=Pemasukan, 2=Pengeluaran")
            tipe_choice = input("Pilih tipe (1/2): ")
            tipe = 'pemasukan' if tipe_choice == '1' else 'pengeluaran'
            
            key = input("Masukkan kode kategori baru: ").strip()
            value = input("Masukkan nama kategori: ").strip()
            
            if key and value:
                fm.category_map.add_category(key, value, tipe)
                print(f"Kategori {tipe} '{key}: {value}' berhasil ditambahkan")
            else:
                print("Kode dan nama kategori tidak boleh kosong")
        
        elif choice == '0':
            print("Terima kasih telah menggunakan aplikasi!")
            break
        
        else:
            print("Pilihan tidak valid")
        
        input("\nTekan Enter untuk melanjutkan...")

if __name__ == "__main__":
    main()